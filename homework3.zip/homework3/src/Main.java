// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String myString = "I study Basic Java!";
        System.out.println("Пред-последний символ: " + myString.charAt(myString.length() - 2));
        System.out.println("Вырезанная подстрока: " + myString.substring(12, 16).toUpperCase());
        System.out.println("Cтрока в нижнем регистре: " + myString.toLowerCase());
        System.out.println("Sum: " + (5 + 3));
        System.out.println("Difference: " + (5 - 3));
        System.out.println("Product: " + (5 * 3));
        System.out.println("Division: " + (5.0 / 3.0));
        }
    }
